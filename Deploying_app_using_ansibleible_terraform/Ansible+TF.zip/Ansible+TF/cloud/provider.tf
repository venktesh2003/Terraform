terraform {
  required_providers {
    aws = {
      source = "hashicorp/aws"
      version = "6.28.0"
    }
  }
}

provider "aws" {
  # Configuration options
#   secret_key =
region = var.region
access_key = "AKIAVRUVVXAHRNNB3WO7"
secret_key = "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"
}

