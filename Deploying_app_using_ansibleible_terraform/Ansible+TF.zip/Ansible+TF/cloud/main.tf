resource "aws_security_group" "web_sg" {

  description = "Allow HTTP and SSH"
  #vpc_id      = data.aws_vpc.default.id

  ingress {
    description = "HTTP"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "SSH"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    description = "All outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  #tags = { Name = "${var.project_name}-sg" }
}



resource "aws_instance" "web" {
  ami           = "ami-069e612f612be3a2b"
  instance_type = var.instance_size
  key_name      = aws_key_pair.keyname.key_name
 
  vpc_security_group_ids = [aws_security_group.web_sg.id]

}

resource "aws_key_pair" "keyname" {
  key_name   = "keyname"
  public_key = file("${path.module}/../config/keyname.pub")

}



