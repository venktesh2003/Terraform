variable "region" {
    type = string
    default = "us-east-1"
  
}
variable "instance_size" {
    type = string
  
}

variable "keyname" {
    type = string
  
}

variable "project_name" {
    default = "my_VM"
  
}