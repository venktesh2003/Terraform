
region   = "us-east-1"
instance_size = "t3.micro"
keyname      = "keyname"
