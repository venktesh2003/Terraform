const API_KEY = "daba60473283468467c80aaa276b8472"; // Replace with your OpenWeatherMap API key

function getWeather() {
  const city = document.getElementById("city").value;
  if (!city) {
    alert("Please enter a city name");
    return;
  }

  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`;

  fetch(url)
    .then(response => {
      if (!response.ok) {
        throw new Error("City not found");
      }
      return response.json();
    })
    .then(data => {
      const temp = data.main.temp;
      const humidity = data.main.humidity;
      const pressure = data.main.pressure;
      const wind = data.wind.speed;
      const description = data.weather[0].description;

      document.getElementById("result").innerHTML = `
        <p>🌍 City: ${city}</p>
        <p>🌡️ Temperature: ${temp} °C</p>
        <p>💧 Humidity: ${humidity}%</p>
        <p>🔽 Pressure: ${pressure} hPa</p>
        <p>🌬️ Wind Speed: ${wind} m/s</p>
        <p>☁️ Condition: ${description}</p>
      `;
    })
    .catch(error => {
      document.getElementById("result").innerHTML = `<p style="color:red;">${error.message}</p>`;
    });
}