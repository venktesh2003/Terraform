import subprocess
import json
import os
import sys

def run(cmd, cwd=None, check=True, capture=False):
    """Run a command, optionally capturing output."""
    if capture:
        result = subprocess.run(cmd, cwd=cwd, text=True, capture_output=True, check=check)
        return result.stdout
    else:
        subprocess.run(cmd, cwd=cwd, check=check)

def main():
    print("Ansible + terraform")

    # Prompt for inputs
    #project_name  = input("Project name (default: simple-rhel-web): ").strip() or "simple-rhel-web"
    aws_region    = input("AWS region (e.g., ap-south-1): ").strip()
    if not aws_region:
        print("AWS region is required.")
        sys.exit(1)

    instance_size = input("EC2 instance type (default: t3.micro): ").strip() or "t3.micro"
    key_name      = input("Existing EC2 key pair name: ").strip()
    if not key_name:
        print("EC2 key pair name is required.")
        sys.exit(1)

    ssh_key_path  = input("Path to your private key file (e.g., ~/.ssh/my-keypair.pem): ").strip()
    if not ssh_key_path:
        print("Private key path is required.")
        sys.exit(1)

    # Write terraform.tfvars
    tfvars_path = os.path.join("cloud", "terraform.tfvars")
    tfvars = f'''
region   = "{aws_region}"
instance_size = "{instance_size}"
keyname      = "{key_name}"
'''
    os.makedirs("cloud", exist_ok=True)
    with open(tfvars_path, "w") as f:
        f.write(tfvars)

    # Terraform: init + apply
    print("\n==> Running Terraform init/apply...")
    run(["terraform", "init"], cwd="cloud")
    run(["terraform", "apply", "-auto-approve"], cwd="cloud")

    # Fetch Terraform outputs
    print("==> Fetching Terraform outputs...")
    outputs_json = run(["terraform", "output", "-json"], cwd="cloud", capture=True)
    outputs = json.loads(outputs_json)
    public_ip = outputs["public_ip"]["value"]
   

    print(f"EC2 Public IP: {public_ip}")
    #print(f"RHEL AMI used: {rhel_ami}")

    # Write Ansible inventory
    print("==> Writing Ansible inventory...")
    os.makedirs("config", exist_ok=True)
    inventory = f"""[web]
{public_ip} ansible_user=ec2-user ansible_ssh_private_key_file={ssh_key_path}
"""
    with open(os.path.join("config", "inventory.ini"), "w") as f:
        f.write(inventory)

    # Run Ansible
    print("\n==> Running Ansible playbook...")
    run(["ansible-playbook", "-i", "inventory.ini", "playbook.yml"], cwd="config")

    print(f"\n✅ Done! Visit http://{public_ip} to see your page.")

if __name__ == "__main__":
    main()